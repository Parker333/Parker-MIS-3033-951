﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JSONGOTQuote
{
    public class GOTAPI
    {
        string quote { get; set; }
        string character { get; set; }
    }
}

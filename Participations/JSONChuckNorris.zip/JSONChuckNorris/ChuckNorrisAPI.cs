﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JSONChuckNorris
{
    public class ChuckNorrisAPI
    {
        public string value { get; set; }

        public override string ToString()
        {
            return value;
        }
    }
}
